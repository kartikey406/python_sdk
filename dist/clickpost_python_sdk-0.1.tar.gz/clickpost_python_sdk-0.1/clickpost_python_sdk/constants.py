CLICKPOST_OC_URL = "https://www.clickpost.in/api/v1/create-order/"
